"""Selenium + pytest automation of manual test cases from IRCTC_Test_Cases.xlsx.

Scope: public search form only. No login, booking or payment is automated.
"""
from datetime import date

import pytest

import config


def test_S03_same_station_is_rejected(search):
    """TC S-03: From and To are the same station -> error shown, search blocked."""
    search.set_from("NDLS")
    search.set_to("NDLS")
    search.click_search()
    search.text_visible("//*[contains(text(),'destination') and contains(text(),'same')]")
    assert "train-list" not in search.driver.current_url


def test_S04_empty_fields_show_error(search):
    """TC S-04: empty From/To -> 'Please submit correct input'."""
    search.click_search()
    search.text_visible(f"//*[contains(text(),'{config.MSG_EMPTY}')]")
    assert "train-list" not in search.driver.current_url


def test_S05_past_dates_are_disabled(search):
    """TC S-05: yesterday's date cannot be selected in the calendar."""
    today = date.today()
    if today.day == 1:
        pytest.skip("No earlier day in the current month to check")
    search.open_calendar()
    cell = search.calendar_day(today.day - 1)
    assert "disabled" in (cell.get_attribute("class") or "").lower()


def test_S08_swap_interchanges_stations(search):
    """TC S-08: swap button exchanges From and To."""
    search.set_from("NDLS")
    search.set_to("MMCT")
    assert "NDLS" in search.from_value() and "MMCT" in search.to_value()
    search.click_swap()
    assert "MMCT" in search.from_value()
    assert "NDLS" in search.to_value()
