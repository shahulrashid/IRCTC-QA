import os

import pytest
from selenium import webdriver
from selenium.webdriver.chrome.options import Options

import config
from sel_search_page import SearchPage


@pytest.fixture
def driver():
    opts = Options()
    if config.HEADLESS:
        opts.add_argument("--headless=new")
    opts.add_argument("--window-size=1366,900")
    d = webdriver.Chrome(options=opts)  # Selenium Manager downloads the driver
    yield d
    d.quit()


@pytest.fixture
def search(driver):
    sp = SearchPage(driver)
    sp.open()
    return sp


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    """Save a screenshot into reports/screenshots when a Selenium test fails."""
    outcome = yield
    report = outcome.get_result()
    if report.when == "call" and report.failed:
        drv = item.funcargs.get("driver")
        if drv:
            os.makedirs("reports/screenshots", exist_ok=True)
            drv.save_screenshot(f"reports/screenshots/{item.name}.png")
