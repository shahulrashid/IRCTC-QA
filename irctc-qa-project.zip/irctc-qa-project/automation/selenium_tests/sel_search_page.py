"""Page Object for the IRCTC search form (Selenium)."""
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

import config


class SearchPage:
    def __init__(self, driver, timeout=15):
        self.driver = driver
        self.wait = WebDriverWait(driver, timeout)

    def open(self):
        self.driver.get(config.BASE_URL)
        self.wait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, config.FROM_INPUT)))

    def _pick_station(self, css, text):
        box = self.driver.find_element(By.CSS_SELECTOR, css)
        box.click()
        box.clear()
        box.send_keys(text)
        self.wait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, config.SUGGESTION)))
        box.send_keys(Keys.ENTER)  # first suggestion is highlighted by default

    def set_from(self, text):
        self._pick_station(config.FROM_INPUT, text)

    def set_to(self, text):
        self._pick_station(config.TO_INPUT, text)

    def click_search(self):
        self.driver.find_element(By.CSS_SELECTOR, config.SEARCH_BTN).click()

    def click_swap(self):
        self.driver.find_element(By.CSS_SELECTOR, config.SWAP_BTN).click()

    def from_value(self):
        return self.driver.find_element(By.CSS_SELECTOR, config.FROM_INPUT).get_attribute("value")

    def to_value(self):
        return self.driver.find_element(By.CSS_SELECTOR, config.TO_INPUT).get_attribute("value")

    def text_visible(self, xpath):
        return self.wait.until(EC.visibility_of_element_located((By.XPATH, xpath)))

    def open_calendar(self):
        self.driver.find_element(By.CSS_SELECTOR, config.DATE_INPUT).click()
        self.wait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, config.CAL_DAY)))

    def calendar_day(self, day):
        cells = self.driver.find_elements(By.CSS_SELECTOR, config.CAL_DAY)
        return next(c for c in cells if c.text.strip() == str(day))
