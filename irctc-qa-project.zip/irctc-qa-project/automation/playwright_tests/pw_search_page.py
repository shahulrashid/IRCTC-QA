"""Page Object for the IRCTC search form (Playwright)."""
import config


class SearchPage:
    def __init__(self, page):
        self.page = page

    def open(self):
        self.page.goto(config.BASE_URL, wait_until="domcontentloaded")
        self.page.locator(config.FROM_INPUT).wait_for(state="visible")

    def _pick_station(self, css, text):
        box = self.page.locator(css)
        box.click()
        box.fill("")
        box.press_sequentially(text, delay=80)
        self.page.locator(config.SUGGESTION).first.wait_for(state="visible")
        box.press("Enter")  # first suggestion is highlighted by default

    def set_from(self, text):
        self._pick_station(config.FROM_INPUT, text)

    def set_to(self, text):
        self._pick_station(config.TO_INPUT, text)

    def click_search(self):
        self.page.locator(config.SEARCH_BTN).click()

    def click_swap(self):
        self.page.locator(config.SWAP_BTN).first.click()

    def from_value(self):
        return self.page.locator(config.FROM_INPUT).input_value()

    def to_value(self):
        return self.page.locator(config.TO_INPUT).input_value()

    def open_calendar(self):
        self.page.locator(config.DATE_INPUT).click()
        self.page.locator(config.CAL_DAY).first.wait_for(state="visible")

    def calendar_day(self, day):
        import re
        return self.page.locator(config.CAL_DAY).filter(has_text=re.compile(rf"^\s*{day}\s*$")).first
