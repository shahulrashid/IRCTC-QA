"""Playwright + pytest automation of manual test cases from IRCTC_Test_Cases.xlsx.

Scope: public search form only. No login, booking or payment is automated.
"""
import re
from datetime import date

import pytest
from playwright.sync_api import expect

import config


def test_S03_same_station_is_rejected(search):
    """TC S-03: From and To are the same station -> error shown, search blocked."""
    search.set_from("NDLS")
    search.set_to("NDLS")
    search.click_search()
    expect(search.page.get_by_text(re.compile(config.MSG_SAME_PATTERN, re.I))).to_be_visible()
    expect(search.page).not_to_have_url(re.compile("train-list"))


def test_S04_empty_fields_show_error(search):
    """TC S-04: empty From/To -> 'Please submit correct input'."""
    search.click_search()
    expect(search.page.get_by_text(config.MSG_EMPTY)).to_be_visible()
    expect(search.page).not_to_have_url(re.compile("train-list"))


def test_S05_past_dates_are_disabled(search):
    """TC S-05: yesterday's date cannot be selected in the calendar."""
    today = date.today()
    if today.day == 1:
        pytest.skip("No earlier day in the current month to check")
    search.open_calendar()
    yesterday = search.calendar_day(today.day - 1)
    expect(yesterday).to_have_class(re.compile("disabled", re.I))


def test_S08_swap_interchanges_stations(search):
    """TC S-08: swap button exchanges From and To."""
    search.set_from("NDLS")
    search.set_to("MMCT")
    assert "NDLS" in search.from_value() and "MMCT" in search.to_value()
    search.click_swap()
    assert "MMCT" in search.from_value()
    assert "NDLS" in search.to_value()
