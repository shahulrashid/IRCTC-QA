"""Shared settings and locators for both the Playwright and Selenium tests.

If a test fails with "element not found", fix the locator HERE (right-click the
element in Chrome, Inspect, and copy a stable id/class). Every test uses these.
"""
import os

BASE_URL = os.getenv("IRCTC_URL", "https://www.irctc.co.in/nget/train-search")
HEADLESS = os.getenv("HEADLESS", "0") == "1"

# Search form (public home page only - no login, no booking, no payment)
FROM_INPUT = "#origin input"
TO_INPUT = "#destination input"
DATE_INPUT = "#jDate input"
SEARCH_BTN = "button.search_btn"
SWAP_BTN = ".fa-arrow-right-arrow-left, .fa-exchange-alt, .fa-exchange"

# Autocomplete suggestion rows and calendar day cells (current month only)
SUGGESTION = "li[role='option']"
CAL_DAY = (
    ".p-datepicker-calendar td:not(.p-datepicker-other-month) span, "
    ".ui-datepicker-calendar td:not(.ui-datepicker-other-month) span"
)

# Text shown by the site (taken from the manual screenshots S-03 and S-04).
# The same-station message is matched loosely because it contains a typo.
MSG_EMPTY = "Please submit correct input"
MSG_SAME_PATTERN = r"destination.*same"
