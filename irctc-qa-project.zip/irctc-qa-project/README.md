# IRCTC Train Booking Journey - QA Test Design, Execution and Automation

A QA project built from a selection task: test the IRCTC train ticket booking journey
(Search, Login, Train selection, Passenger details, Payment, Booking confirmation).

It has two parts:

1. **Manual testing** - 74 designed test cases, 18 executed on the live site with screenshot evidence.
2. **Automation** - 4 of the executed cases automated twice, once with **Playwright** and once with
   **Selenium**, both using Python and pytest.

## Project structure

```
docs/            IRCTC_Test_Cases.xlsx, IRCTC_evidence_report.pdf
screenshots/     Evidence for executed cases (named by test case ID)
automation/
  config.py                 URL and locators (edit here if the site changes)
  playwright_tests/         Playwright page object + tests
  selenium_tests/           Selenium page object + tests
reports/         HTML test report (generated)
```

## Manual testing summary

| Stage | Total | Executed (Pass) | Not run | Design only |
|---|---|---|---|---|
| Search | 15 | 10 | 5 | - |
| Login | 11 | 2 | 9 | - |
| Train selection | 12 | 6 | 6 | - |
| Passenger details | 12 | 0 | 12 | - |
| Payment | 11 | - | - | 11 |
| Booking confirmation | 8 | - | - | 8 |
| Cross-cutting | 5 | 0 | 5 | - |
| **Total** | **74** | **18** | **37** | **19** |

Payment and Booking confirmation are designed from expected behaviour only. No real payment was made.

### Key findings

- Same-station error text reads `can"t` (straight double quote instead of an apostrophe).
- Search calendar allows dates up to 63 days ahead, not the 60 days first assumed.
- Empty-search error ("Please submit correct input") does not say which field is wrong.
- Tatkal quota is not listed for a December travel date.
- Full list of 16 observations is in the report and the Observations sheet.

## Automation

### Traceability (manual case to automated test)

| Test case | Scenario | Playwright test | Selenium test |
|---|---|---|---|
| S-03 | Same From and To station is rejected | `test_S03_same_station_is_rejected` | `test_S03_same_station_is_rejected` |
| S-04 | Empty fields show an error | `test_S04_empty_fields_show_error` | `test_S04_empty_fields_show_error` |
| S-05 | Past dates are disabled | `test_S05_past_dates_are_disabled` | `test_S05_past_dates_are_disabled` |
| S-08 | Swap button interchanges stations | `test_S08_swap_interchanges_stations` | `test_S08_swap_interchanges_stations` |

### Design choices

- **Page Object Model:** one page class per tool; tests contain only the test steps.
- **One config file:** all locators and messages live in `automation/config.py`.
- **Scope kept safe:** only the public search form is automated. Login, booking and payment are not
  automated, and the tests make very few requests.
- **Failure evidence:** Selenium saves a screenshot on failure; the HTML report is written to `reports/`.

### Setup

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
playwright install chromium
```

### Run

```bash
pytest automation/playwright_tests       # Playwright only
pytest automation/selenium_tests         # Selenium only
pytest                                   # both
HEADLESS=1 pytest                        # without a visible browser (Windows: set HEADLESS=1)
```

The report is saved at `reports/report.html`.

### Notes

- Locators were written from the page layout and may need a small update. If a test fails with
  "element not found", inspect the element in Chrome DevTools and fix it in `automation/config.py`.
- IRCTC may show pop-ups or bot checks; run the tests with a visible browser first.
- Selenium needs Google Chrome installed (the driver is downloaded automatically).

## Tools

Python, pytest, Playwright, Selenium, pytest-html, Excel, LaTeX, Git.

## Author

Shahul Rashid T
